# SeaOwl Ulauncher

A theme for Ulauncher.

## Screenshot
![](./SeaOwl.png)

## Installation

```sh
mkdir -p ~/.config/ulauncher/user-themes
git clone https://github.com/Surendrajat/SeaOwl-Ulauncher-theme \
  ~/.config/ulauncher/user-themes/SeaOwl
```

## Credit

- [SeaOwl wallpaper & theme](https://github.com/VijayLalwani/SeaOwl)
- [WhiteSur Dark theme](https://github.com/Raayib/WhiteSur-Dark-ulauncher)